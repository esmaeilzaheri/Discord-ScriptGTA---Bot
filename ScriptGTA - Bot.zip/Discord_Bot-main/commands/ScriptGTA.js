module.exports = {
	name: 'ScriptGTA',
	description: 'ScriptGTA Community.',
	execute(message) {
		message.channel.send('ScriptGTA Community: https://ScriptGTA.ir');
	},
};