module.exports = {
	name: 'about',
	description: 'About ScriptGTA Bot.',
	execute(message) {
		message.channel.send('ScriptGTA Discord Bot - By: MH11');
	},
};