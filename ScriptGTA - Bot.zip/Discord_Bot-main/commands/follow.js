module.exports = {
	name: 'follow',
	description: 'GAMEGG Social Networks.',
	execute(message) {
		message.channel.send('Telegram: https://t.me/ScriptGTA'),
		message.channel.send('Instagram: https://idpay.ir/ScriptGTA'),
		message.channel.send('Discord: https://discord.gg/wJRxFzVsu2'),
		message.channel.send('YouTube: https://www.youtube.com/channel/UCTMswN10zL2DYrUCh-3kcTw'),
		message.channel.send('Founder: t.me/FounderServerBot');
		message.channel.send('ساخته شده با ❤️ توسط تیم اسکریپت جی تی ای');
	},
};