module.exports = {
	name: 'naab',
	description: 'NaaB Bax Clan.',
	execute(message) {
		message.channel.send('NaaB Bax Clan Members: https://naab.ScriptGTA.ir');
	},
};